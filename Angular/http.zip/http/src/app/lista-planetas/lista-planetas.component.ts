import { Component, OnInit } from '@angular/core';
import { SwService } from '../sw.service';
import { async } from 'rxjs/internal/scheduler/async';


@Component({
  selector: 'app-lista-planetas',
  templateUrl: './lista-planetas.component.html',
  styleUrls: ['./lista-planetas.component.css']
})
export class ListaPlanetasComponent implements OnInit {
  planetas: any[]
  numPaginas: number;
  paginaActual: number = 1;


  constructor(private swService: SwService) { }

  ngOnInit() {
    this.mostrarPlanetas()
  }

  paginado(avance) {
    if ((avance < 0 && this.paginaActual > 1)
      || (avance > 0 && this.paginaActual < this.numPaginas)) {
      this.paginaActual += avance;
      this.mostrarPlanetas()
    }

  }
  mostrarPlanetas() {

    // CON EL OBSERVABLE, ME DESUSCRIBO AL FINAL
    let obs$ = this.swService.getPlanetsObservable(this.paginaActual)
      .subscribe(resultado => {
        this.planetas = resultado['results']
        this.numPaginas = Math.ceil(resultado['count'] / 10)
        obs$.unsubscribe()
      })
    //CON PROMESA
    // this.swService.getPlanetsPromise(this.paginaActual)
    //   .then(function (res): any {
    //     this.planetas = res['results']
    //     this.numPaginas = Math.ceil(res['count'] / 10)
    //   }.bind(this));

    // console.log(this.cosas())


  }


  async cosas() {
    let resultado = await this.swService.getPlanetsAsync()
    return resultado;
  }

}
